-- AGROINCO: cambio de numero de WhatsApp  4076 9228  ->  4001 6659
-- Ejecutar UNA VEZ en phpMyAdmin (pestana "SQL") sobre la base servicom001_AgroInco.
-- Los reemplazos miden lo mismo, por lo que los datos serializados quedan intactos.
UPDATE wp_posts SET post_content = REPLACE(REPLACE(post_content,'40769228','40016659'),'4076 9228','4001 6659'),
                    post_excerpt = REPLACE(REPLACE(post_excerpt,'40769228','40016659'),'4076 9228','4001 6659');
UPDATE wp_postmeta SET meta_value = REPLACE(REPLACE(meta_value,'40769228','40016659'),'4076 9228','4001 6659');
UPDATE wp_options SET option_value = REPLACE(REPLACE(option_value,'40769228','40016659'),'4076 9228','4001 6659');
DELETE FROM wp_postmeta WHERE meta_key IN ('_elementor_element_cache','_elementor_css');
DELETE FROM wp_options WHERE option_name LIKE '\_transient\_%' OR option_name LIKE '\_site\_transient\_%';
