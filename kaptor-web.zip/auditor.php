<?php
/**
 * Kaptor - Auditor web.
 *
 * Se pega una dirección (o una lista entera salida del extractor) y Kaptor
 * revisa cada sitio en seis frentes: velocidad, celular, Google, seguridad,
 * contacto y visibilidad en las IA. De cada uno sale un informe con la marca
 * del usuario, listo para enviárselo al dueño del negocio.
 *
 * Esta página solo arma el formulario y la lista de resultados: el trabajo lo
 * hace api/auditar.php por fases, y el informe vive en informe.php.
 */
declare(strict_types=1);

require_once __DIR__ . '/includes/bootstrap.php';
require_once CR_INCLUDES . '/plantilla.php';

cr_exigir_sesion();

// La misma página sirve para los tres análisis: lo que cambia son los textos
// y el modo con el que se crea la auditoría. seo.php y malware.php entran por
// aquí fijando $modo antes de incluir este archivo.
$modo = $modo ?? (string) ($_GET['modo'] ?? 'completo');
if (!in_array($modo, Auditor::MODOS, true)) { $modo = 'completo'; }

$copia = [
    'completo' => [
        'activo'  => 'auditor',
        'titulo'  => 'Auditor web',
        'etiqueta' => 'Diagnóstico técnico',
        'h1'      => 'Audita un sitio y entrega el informe',
        'sub'     => 'Pega una dirección y Kaptor revisa velocidad, celular, Google, seguridad, '
                   . 'contacto, código malicioso y visibilidad en las inteligencias artificiales. '
                   . 'Sale un informe con tu marca, listo para enviar.',
        'boton'   => 'Auditar',
        'paso1'   => '¿Qué sitios quieres revisar?',
    ],
    'seo' => [
        'activo'  => 'seo',
        'titulo'  => 'Análisis SEO',
        'etiqueta' => 'Posicionamiento en Google',
        'h1'      => 'Cuánto SEO tiene y qué falta para el 100 %',
        'sub'     => 'Kaptor recorre las páginas del sitio, comprueba TODOS sus enlaces uno a uno '
                   . 'y compara las páginas entre sí. Al final da la nota real y la lista exacta '
                   . 'de qué cambiar, con los puntos que devuelve cada arreglo.',
        'boton'   => 'Analizar el SEO',
        'paso1'   => '¿Qué sitio quieres analizar?',
    ],
    'malware' => [
        'activo'  => 'malware',
        'titulo'  => 'Buscar virus',
        'etiqueta' => 'Seguridad del sitio',
        'h1'      => 'Busca virus y código malicioso',
        'sub'     => 'Kaptor recorre el sitio, abre sus archivos de código uno a uno y pide la '
                   . 'página haciéndose pasar por Google y por un celular, que es donde se esconde '
                   . 'lo que un vistazo normal no ve. Y pregunta a los motores antivirus.',
        'boton'   => 'Buscar virus',
        'paso1'   => '¿Qué sitios quieres revisar?',
    ],
][$modo];

$activo = Ajustes::activo('auditor_activo', true);
$sinPsi = trim(Ajustes::obtener('psi_clave')) === '' && Ajustes::activo('psi_activo', true);

// Últimas auditorías del usuario, para volver a un informe sin buscarlo.
$historial = Auditor::historial(Auth::id(), 12, $modo);

// Se puede llegar desde otra página con las direcciones ya puestas.
$precargado = trim((string) ($_GET['sitios'] ?? ''));

cr_cabecera([
    'titulo'      => $copia['titulo'],
    'descripcion' => 'Analiza cualquier sitio web y genera un informe con tu marca.',
    'activo'      => $copia['activo'],
    'css'         => ['auditor.css'],
]);
?>

<section class="seccion-auditor">
  <div class="contenedor">

    <header class="aud-intro">
      <p class="etiqueta-seccion"><span class="punto"></span> <?= e($copia['etiqueta']) ?></p>
      <h1><?= cr_titulo_brillo($copia['h1']) ?></h1>
      <p class="sub"><?= e($copia['sub']) ?></p>
    </header>

    <?php if (!$activo): ?>
      <div class="aviso aviso-mal">El auditor está desactivado en los ajustes del panel.</div>
    <?php endif; ?>

    <div class="aud-cuadro">
      <form id="form-auditor" autocomplete="off" novalidate>
        <?= Seguridad::campoCsrf() ?>
        <input type="hidden" name="modo" id="aud-modo" value="<?= e($modo) ?>">

        <div class="paso-bloque">
          <span class="paso-n">01</span>
          <div class="paso-cuerpo">
            <label for="sitios" class="paso-titulo"><?= e($copia['paso1']) ?></label>
            <textarea id="sitios" name="sitios" rows="4" spellcheck="false"
                      placeholder=""><?= e($precargado) ?></textarea>
            <p class="paso-nota">Hasta <?= e((string) Ajustes::entero('auditor_max_lote', 50, 1, 300)) ?> sitios por tanda. No hace falta escribir «https://».</p>
          </div>
        </div>

        <?php if ($modo === 'completo'): ?>
        <div class="paso-bloque">
          <span class="paso-n">02</span>
          <div class="paso-cuerpo">
            <label for="rivales" class="paso-titulo">
              Compáralo con su competencia
              <span class="opcional">opcional</span>
            </label>
            <textarea id="rivales" name="rivales" rows="2" spellcheck="false"
                      placeholder=""></textarea>
            <p class="paso-nota">
              Hasta tres. El informe enseñará lado a lado quién va ganando en cada área:
              es lo que cierra la venta. Solo funciona cuando auditas <strong>un</strong> sitio.
            </p>
          </div>
        </div>
        <?php endif; ?>

        <div class="aud-acciones">
          <button type="submit" class="btn btn-oro btn-grande" id="btn-auditar">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" aria-hidden="true">
              <path d="M12 3v3M12 18v3M3 12h3M18 12h3"/><circle cx="12" cy="12" r="5.2"/><circle cx="12" cy="12" r="1.4" fill="currentColor" stroke="none"/>
            </svg>
            <?= e($copia['boton']) ?>
          </button>
          <button type="button" class="btn btn-fantasma oculto" id="btn-parar">Detener</button>
        </div>

        <?php if ($sinPsi): ?>
          <p class="aud-consejo">
            <strong>Consejo:</strong> añade tu clave gratuita de Google en
            <?php if (Auth::esAdmin()): ?><a href="<?= e(cr_url('admin/ajustes.php#auditor')) ?>">Ajustes</a><?php else: ?>Ajustes<?php endif; ?>
            y cada informe traerá además la nota oficial de velocidad de Google. Son 25.000 consultas gratis al día.
          </p>
        <?php endif; ?>
      </form>
    </div>

    <!-- Progreso y resultados ------------------------------------------- -->
    <div id="aud-panel" class="aud-panel oculto">
      <div class="aud-panel-cab">
        <h2 id="aud-titulo">Analizando…</h2>
        <p id="aud-aviso" class="aud-aviso oculto"></p>
      </div>
      <div id="aud-lista" class="aud-lista"></div>
    </div>

    <!-- Historial --------------------------------------------------------- -->
    <?php if ($historial): ?>
      <section class="aud-historial" id="aud-historial">
        <h2>Auditorías recientes</h2>
        <div class="aud-lista">
          <?php foreach ($historial as $a):
            $nota = $a['nota'] !== null ? (int) $a['nota'] : null;
            $color = $nota !== null ? Informe::color($nota) : 'gris';
          ?>
            <article class="aud-fila">
              <div class="aud-nota aud-<?= e($color) ?>">
                <?= $nota !== null ? e((string) $nota) : '—' ?>
              </div>
              <div class="aud-datos">
                <p class="aud-host"><?= e($a['host']) ?></p>
                <p class="aud-meta">
                  <?= e($a['titulo'] ?: 'Sin título') ?> ·
                  <?= e(cr_fecha($a["creado"], false)) ?>
                </p>
              </div>
              <div class="aud-botones">
                <?php if ($a['estado'] === 'listo'): ?>
                  <a class="btn btn-fino" href="<?= e(cr_url('informe.php?id=' . (int) $a['id'])) ?>">Ver informe</a>
                <?php else: ?>
                  <span class="aud-estado"><?= e($a['estado'] === 'error' ? 'No se pudo' : 'Sin terminar') ?></span>
                <?php endif; ?>
              </div>
            </article>
          <?php endforeach; ?>
        </div>
      </section>
    <?php endif; ?>

  </div>
</section>

<script>
window.CR_AUDITOR = { api: <?= json_encode(cr_url('api/auditar.php')) ?> };
</script>
<script src="<?= e(cr_url('assets/js/auditor.js')) ?>?v=<?= e(CR_VERSION) ?>" defer></script>

<?php cr_pie(false); ?>
