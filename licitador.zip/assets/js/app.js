(function(){
'use strict';
var $=function(s,c){return (c||document).querySelector(s)},$$=function(s,c){return Array.prototype.slice.call((c||document).querySelectorAll(s))};
var reduce=window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches;

/* Tema claro/oscuro */
$$('[data-theme-toggle]').forEach(function(b){b.addEventListener('click',function(){
  var d=document.documentElement,n=d.getAttribute('data-theme')==='light'?'dark':'light';d.setAttribute('data-theme',n);
  try{localStorage.setItem('lic-theme',n);}catch(e){}
});});
/* Menú móvil */
var mb=$('[data-menu]');if(mb){mb.addEventListener('click',function(){var n=$('#nav');var o=n.classList.toggle('open');mb.setAttribute('aria-expanded',o?'true':'false');});
  $$('#nav a').forEach(function(a){a.addEventListener('click',function(){$('#nav').classList.remove('open');});});}

/* Revelado al hacer scroll */
var rv=$$('.reveal');
if('IntersectionObserver' in window&&!reduce){
  var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target);}});},{threshold:.12,rootMargin:'0px 0px -40px 0px'});
  rv.forEach(function(el,i){el.style.transitionDelay=(i%4)*70+'ms';io.observe(el);});
}else{rv.forEach(function(el){el.classList.add('in');});}

/* Contadores animados */
function fmt(n){return String(n).replace(/\B(?=(\d{3})+(?!\d))/g,',');}
function runCount(el){
  var to=parseInt(el.getAttribute('data-count'),10)||0,pre=el.getAttribute('data-prefix')||'',suf=el.getAttribute('data-suffix')||'';
  if(reduce||to===0){el.textContent=pre+fmt(to)+suf;return;}
  var t0=null,dur=1400;
  function step(t){if(!t0)t0=t;var p=Math.min(1,(t-t0)/dur),e=1-Math.pow(1-p,3);el.textContent=pre+fmt(Math.round(to*e))+suf;if(p<1)requestAnimationFrame(step);}
  requestAnimationFrame(step);
}
var cs=$$('[data-count]');
if('IntersectionObserver' in window){var co=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){runCount(e.target);co.unobserve(e.target);}});},{threshold:.4});cs.forEach(function(c){co.observe(c);});}
else{cs.forEach(runCount);}

/* Confirmaciones */
document.addEventListener('click',function(e){var b=e.target.closest('button[data-confirm]');if(b&&!confirm(b.getAttribute('data-confirm')))e.preventDefault();});
document.addEventListener('submit',function(e){var f=e.target;if(f.getAttribute&&f.getAttribute('data-confirm')&&!confirm(f.getAttribute('data-confirm')))e.preventDefault();});

/* Copiar bloques de código */
$$('pre[data-copy]').forEach(function(p){p.title='Clic para copiar';p.addEventListener('click',function(){
  if(navigator.clipboard){navigator.clipboard.writeText(p.textContent.trim()).then(function(){toast('Copiado');});}
});});

/* Aviso flotante */
function toast(msg){var t=document.createElement('div');t.className='toast';t.setAttribute('role','status');t.textContent=msg;document.body.appendChild(t);
  requestAnimationFrame(function(){t.classList.add('show');});setTimeout(function(){t.classList.remove('show');setTimeout(function(){t.remove();},400);},2200);}

/* Acciones sin recargar (guardar / descartar / participar) */
$$('form[data-ajax-actions]').forEach(function(f){f.addEventListener('submit',function(e){
  var s=e.submitter;if(!s||!window.fetch||!window.FormData)return;
  e.preventDefault();var fd=new FormData(f);fd.set(s.name,s.value);fd.set('ajax','1');
  fetch(f.action,{method:'POST',body:fd,credentials:'same-origin',headers:{'X-Requested-With':'fetch'}}).then(function(r){return r.json();}).then(function(j){
    if(!j.ok)throw 0;var card=f.closest('.tcard');
    var m={guardar:'Guardado en tu lista',participar:'Marcado: voy a participar',descartar:'Descartado',restaurar:'Restaurado'};toast(m[s.value]||'Listo');
    if(s.value==='descartar'||s.value==='restaurar'){card.classList.add('gone');setTimeout(function(){card.remove();},400);}
  }).catch(function(){f.submit();});
});});

/* Lista de requisitos con casillas */
var cl=$('[data-checklist]');
if(cl){
  var upd=function(){var all=$$('input[type=checkbox]',cl),d=all.filter(function(c){return c.checked;}).length,p=$('[data-check-progress]');if(p)p.textContent='('+d+' de '+all.length+' listos)';};
  upd();
  cl.addEventListener('change',function(e){var c=e.target;if(!c.matches('input[type=checkbox]'))return;upd();
    var fd=new FormData();fd.set('_csrf',cl.getAttribute('data-token'));fd.set('idx',c.getAttribute('data-idx'));fd.set('on',c.checked?'1':'0');
    fetch(cl.getAttribute('data-url'),{method:'POST',body:fd,credentials:'same-origin'}).catch(function(){toast('No se pudo guardar');});});
}

/* Marcador de mediana en precios */
var rg=$('[data-range]');
if(rg){var v=rg.getAttribute('data-range').split(',').map(parseFloat),mn=v[0],md=v[1],mx=v[2],m=$('.range-med',rg);if(m&&mx>mn)m.style.left=(((md-mn)/(mx-mn))*100)+'%';}

/* Asistente: chips + pasos */
var w=$('[data-wizard]');
if(w){
  var list=$('[data-chip-list]',w),field=$('[data-chip-field]',w),hid=$('[data-chip-value]',w),limit=parseInt(w.getAttribute('data-limit'),10)||10,dl=$('#sugerencias');
  var kws=function(){return $$('.chip',list).map(function(c){return c.firstChild.textContent.trim();});};
  var sync=function(){hid.value=kws().join(', ');};
  var add=function(t){t=t.replace(/[,;]+/g,' ').trim();if(!t)return;
    if(kws().some(function(k){return k.toLowerCase()===t.toLowerCase();}))return;
    if(kws().length>=limit){toast('Tu plan permite '+limit+' palabras clave');return;}
    var c=document.createElement('span');c.className='chip';c.appendChild(document.createTextNode(t));
    var b=document.createElement('button');b.type='button';b.setAttribute('aria-label','Quitar '+t);b.textContent='×';c.appendChild(b);list.appendChild(c);sync();};
  list.addEventListener('click',function(e){var b=e.target.closest('button');if(b){b.parentNode.remove();sync();}});
  field.addEventListener('keydown',function(e){if(e.key==='Enter'||e.key===','){e.preventDefault();add(field.value);field.value='';}});
  field.addEventListener('change',function(){if(dl&&Array.prototype.some.call(dl.options,function(o){return o.value===field.value;})){add(field.value);field.value='';}});
  field.addEventListener('blur',function(){if(field.value.trim()){add(field.value);field.value='';}});
  var tm;field.addEventListener('input',function(){clearTimeout(tm);var q=field.value.trim();if(q.length<2||!window.fetch)return;
    tm=setTimeout(function(){fetch(w.getAttribute('data-suggest')+(w.getAttribute('data-suggest').indexOf('?')>-1?'&':'?')+'q='+encodeURIComponent(q),{credentials:'same-origin'}).then(function(r){return r.json();}).then(function(a){
      dl.innerHTML='';a.forEach(function(s){var o=document.createElement('option');o.value=s;dl.appendChild(o);});}).catch(function(){});},220);});
  $$('[data-add-kws]',w).forEach(function(b){b.addEventListener('click',function(){b.getAttribute('data-add-kws').split(',').forEach(add);});});
  var panes=$$('.wiz-pane',w),steps=$$('.wiz-steps li',w),cur=0;
  var go=function(n){cur=n;panes.forEach(function(p,i){p.classList.toggle('on',i===n);});steps.forEach(function(s,i){s.classList.toggle('on',i<=n);});window.scrollTo({top:0,behavior:reduce?'auto':'smooth'});};
  $$('[data-next]',w).forEach(function(b){b.addEventListener('click',function(){if(cur===0){if(field.value.trim()){add(field.value);field.value='';}if(!kws().length){toast('Agrega al menos una palabra clave');field.focus();return;}}go(Math.min(cur+1,panes.length-1));});});
  $$('[data-prev]',w).forEach(function(b){b.addEventListener('click',function(){go(Math.max(cur-1,0));});});
  w.addEventListener('submit',function(){if(field.value.trim()){add(field.value);field.value='';}sync();});
}
})();
